//
//  LocalNotification.swift
//  AlarmTestApp
//
//  Created by Parbhat Jayaswal on 05/10/22.
//

import Foundation
import UIKit

class LocalNotification {
    
    static var shared = LocalNotification()
    
    func setNotification(alarmInfo: CDAlarmModal?) {
        
        guard let info = alarmInfo else { return }

        let dateAsString = info.time! + " " + info.ampm!
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        let date = dateFormatter.date(from: dateAsString)
        
        dateFormatter.dateFormat = "HH:mm"
        let date24 = dateFormatter.string(from: date!)
        
        // Actual Time
        let datTime: Date = createDate(weekday: Int(info.day!)!, hour: Int(date24.components(separatedBy: ":").first!)!, minute: Int(date24.components(separatedBy: ":").last!)!)
                            
        setNotificationReminder(at: datTime, id: "\(info.id)", titles: info.alarm_name!, body: "", soundType: "Alarm")
    }
        
    func unSetNotification(alarmInfo: CDAlarmModal?) {
        guard let info = alarmInfo else { return }
        unsetNotificationReminder(id: "\(info.id)")
    }
    
    // Convert Date
    fileprivate func createDate(weekday: Int, hour: Int, minute: Int) -> Date {
        var components = DateComponents()
        components.hour = hour
        components.minute = minute
        components.year = 2022
        components.weekday = weekday // sunday = 1 ... saturday = 7
        components.weekdayOrdinal = 10
        components.timeZone = .current
        
        let calendar = Calendar(identifier: .gregorian)
                
        return calendar.date(from: components)!
    }
    
    // Add Notification Alarm
    fileprivate  func setNotificationReminder(at date: Date, id: String, titles:String, body: String, soundType: String) {
        let notificationCenter = UNUserNotificationCenter.current()
        
        let triggerWeekly = Calendar.current.dateComponents([.weekday,.hour,.minute,.second], from: date)
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerWeekly, repeats: false)
        
        let content = UNMutableNotificationContent()
        content.title = titles
        content.body = body
        content.badge = 1
        
        if soundType == "Alarm" {
            content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "myalarm.mp3"))
        } else {
            content.sound = UNNotificationSound.default
        }

        let request = UNNotificationRequest(identifier: id, content: content, trigger: trigger)
        notificationCenter.add(request) {(error) in
            if let error = error {
                print("Uh oh! We had an error: \(error)")
            }
        }
    }
    
    // Remove Notification Alarm
    fileprivate func unsetNotificationReminder(id: String) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [id])
    }
    
}
