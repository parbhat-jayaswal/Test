//
//  Screen1Cell.swift
//  AlarmTestApp
//
//  Created by Parbhat Jayaswal on 05/10/22.
//

import UIKit

class Screen1Cell: UITableViewCell {
    
    @IBOutlet weak var timeLbl: UILabel!
    @IBOutlet weak var ampmLbl: UILabel!
    @IBOutlet weak var alarmOnOffSwitchBtn: UISwitch!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func configCell(info: CDAlarmModal) {
        timeLbl.text = info.time
        ampmLbl.text = info.ampm
        alarmOnOffSwitchBtn.isOn = info.is_active
        
        if info.is_active == true {
            timeLbl.textColor = .black
            ampmLbl.textColor = .black
            backgroundColor = .white
            
        } else {
            timeLbl.textColor = .darkGray
            ampmLbl.textColor = .darkGray
            backgroundColor = .lightGray
        }
    }
    
}
