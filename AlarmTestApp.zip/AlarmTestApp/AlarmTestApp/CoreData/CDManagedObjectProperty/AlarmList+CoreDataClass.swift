//
//  AlarmList+CoreDataClass.swift
//  AlarmTestApp
//
//  Created by Parbhat Jayaswal on 06/10/22.
//
//

import Foundation
import CoreData

@objc(AlarmList)
public class AlarmList: NSManagedObject {

}
