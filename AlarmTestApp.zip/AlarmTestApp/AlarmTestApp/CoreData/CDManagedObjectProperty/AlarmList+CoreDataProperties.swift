//
//  AlarmList+CoreDataProperties.swift
//  AlarmTestApp
//
//  Created by Parbhat Jayaswal on 06/10/22.
//
//

import Foundation
import CoreData


extension AlarmList {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<AlarmList> {
        return NSFetchRequest<AlarmList>(entityName: "AlarmList")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var time: String?
    @NSManaged public var ampm: String?
    @NSManaged public var alarm_name: String?
    @NSManaged public var day: String?
    @NSManaged public var is_active: Bool

    func convertToAlarm() -> CDAlarmModal {
        return CDAlarmModal(id: id!, time: time, ampm: ampm, alarm_name: alarm_name, day: day, is_active: is_active)
    }
    
}

extension AlarmList : Identifiable {

}
