//
//  CDAlarmModal.swift
//  AlarmTestApp
//
//  Created by Parbhat Jayaswal on 05/10/22.
//

import Foundation

struct CDAlarmModal {
    var id: UUID
    var time: String?
    var ampm: String?
    var alarm_name: String?
    var day: String?
    var is_active: Bool
}
