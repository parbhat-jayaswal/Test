//
//  ViewController.swift
//  AlarmTestApp
//
//  Created by Parbhat Jayaswal on 05/10/22.
//

import UIKit
import CoreData

class Screen1: UIViewController {
    
    @IBOutlet weak var emptyListLbl: UILabel!
    @IBOutlet weak var tblView: UITableView!

    private var dataSource: [CDAlarmModal] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        enableNotificationBanner()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let result = PersistentStorage.shared.fetchManagedObject(managedObject: AlarmList.self)
        dataSource.removeAll()
        
        result?.forEach({ (info) in
            dataSource.insert(info.convertToAlarm(), at: 0)
        })
        
        tblView.reloadData()
    }

    @IBAction func addAlarmBtnAction(_ sender: UIButton) {
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Screen2") as! Screen2
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
}

extension Screen1: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dataSource.count == 0 {
            emptyListLbl.isHidden = false
        } else {
            emptyListLbl.isHidden = true
        }
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Screen1Cell", for: indexPath) as! Screen1Cell
        cell.configCell(info: dataSource[indexPath.row])
        cell.alarmOnOffSwitchBtn.tag = indexPath.row
        cell.alarmOnOffSwitchBtn.addTarget(self, action: #selector(self.alarmOnOffSwitchBtnAction(_:)), for: .valueChanged)
        return cell
    }
    
    @objc func alarmOnOffSwitchBtnAction(_ sender : UISwitch!) {
        let indexPath = IndexPath(row:sender.tag, section: 0)
        let cell = self.tblView.cellForRow(at: indexPath) as! Screen1Cell
        let index = dataSource[sender.tag]
        
        
        if cell.alarmOnOffSwitchBtn.isOn {
            cell.timeLbl.textColor = .black
            cell.ampmLbl.textColor = .black
            cell.backgroundColor = .white
            LocalNotification.shared.setNotification(alarmInfo: index)
        } else {
            cell.timeLbl.textColor = .darkGray
            cell.ampmLbl.textColor = .darkGray
            cell.backgroundColor = .lightGray
            LocalNotification.shared.unSetNotification(alarmInfo: index)
        }

        let cdAlarm = getCDAlarms(byIdentifier: index.id)
        
        guard cdAlarm != nil else {return}
        
        cdAlarm?.time = index.time
        cdAlarm?.ampm = index.ampm
        cdAlarm?.alarm_name = index.alarm_name
        cdAlarm?.day = index.day
        cdAlarm?.is_active = sender.isOn
        
        PersistentStorage.shared.saveContext()
        
    }
    
    private func getCDAlarms(byIdentifier id: UUID) -> AlarmList? {
        let fetchRequest = NSFetchRequest<AlarmList>(entityName: "AlarmList")
        let predicate = NSPredicate(format: "id==%@", id as CVarArg)
        
        fetchRequest.predicate = predicate
        do {
            let result = try PersistentStorage.shared.context.fetch(fetchRequest).first
            
            guard result != nil else {return nil}
            
            return result
            
        } catch let error {
            debugPrint(error)
        }
        
        return nil
    }
    
}

extension Screen1 : UNUserNotificationCenterDelegate {
    
    func enableNotificationBanner() {
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().requestAuthorization(
            options: [.alert,.sound,.badge],
            completionHandler: { (granted,error) in
                if granted{
                    print("")
                } else {
                    
                    let alert = UIAlertController(title: "Alarm", message: "In order to get the alarm notification from the application, Please turn on notification permission from the settings app", preferredStyle: .alert)
                    let alertAction = UIAlertAction(title: "Okay", style: .default, handler: nil)
                    alert.addAction(alertAction)
                    DispatchQueue.main.async {
                        self.present(alert, animated: true, completion: nil)
                    }
                     
                }
            })
    }
    
    
    func addNotification(content:UNNotificationContent,trigger:UNNotificationTrigger?, indentifier:String){
        let request = UNNotificationRequest(identifier: indentifier, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: {
            (errorObject) in
            if let error = errorObject{
                print("Error \(error.localizedDescription) in notification \(indentifier)")
            }
        })
    }
    
    // MARK: - Delegates
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.alert,.sound])
    }
    
}
