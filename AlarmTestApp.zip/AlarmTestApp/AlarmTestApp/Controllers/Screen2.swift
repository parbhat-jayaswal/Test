//
//  Screen2.swift
//  AlarmTestApp
//
//  Created by Parbhat Jayaswal on 05/10/22.
//

import UIKit

extension Date {
    func dayNumberOfWeek() -> Int? {
        return Calendar.current.dateComponents([.weekday], from: self).weekday
    }
}

enum AM_PM_Type {
    case AM
    case PM
}

class Screen2: UIViewController {
    
    @IBOutlet weak var timeTF: UITextField!
    @IBOutlet weak var amLbl: UILabel!
    @IBOutlet weak var pmLbl: UILabel!
    @IBOutlet weak var alarmNameTF: UITextField!
    
    private var type : AM_PM_Type = .AM
    private var selectedType: String = "AM"
    
    private let timePicker = UIPickerView()
    private var selectedMonth = ""
    private var selectedYear = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        timePicker.delegate = self
        timeTF.inputView = timePicker
    }
    
    @IBAction func goBackAction(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    @IBAction func amBtnAction(_ sender: UIButton) {
        type = .AM
        setupAmPm()
        selectedType = "AM"
    }
    
    @IBAction func pmBtnAction(_ sender: UIButton) {
        type = .PM
        setupAmPm()
        selectedType = "PM"
    }
    
    func setupAmPm() {
        switch type {
        case .AM:
            amLbl.textColor = .black
            pmLbl.textColor = .lightGray
        case .PM:
            amLbl.textColor = .lightGray
            pmLbl.textColor = .black
        }
    }
    
    @IBAction func saveBtnAction(_ sender: UIButton) {
        guard let name = alarmNameTF.text, name != "" else {
            showAlert(title: "Alarm", msg: "Please enter alarm name!")
            return
        }
        
        let UUUID_Id = UUID()
        
        let cdAlarm = AlarmList(context: PersistentStorage.shared.context)
        cdAlarm.id = UUUID_Id
        cdAlarm.time = timeTF.text
        cdAlarm.ampm = selectedType
        cdAlarm.alarm_name = name
        cdAlarm.day = "\(Date().dayNumberOfWeek()!)"
        cdAlarm.is_active = true
        PersistentStorage.shared.saveContext()
        
        let alarm = CDAlarmModal(id: UUUID_Id, time: timeTF.text!, ampm: selectedType, alarm_name: name, day: "\(Date().dayNumberOfWeek()!)", is_active: true)
        LocalNotification.shared.setNotification(alarmInfo: alarm)

        dismiss(animated: true)
    }
    
    func showAlert(title: String, msg: String) {
        let alert = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true)
    }
    
}

// MARK: UIPickerView Delegation
extension Screen2: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0 {
            return hour.count
        } else {
            return minutes.count
        }
    }
    
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 {
            return hour[row]
        } else {
            return minutes[row]
        }
    }
    
    func pickerView( _ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0 {
            selectedMonth = "\(hour[row]):"
        } else{
            selectedYear = "\(minutes[row])"
        }
        timeTF.text = selectedMonth + selectedYear
    }
    
}
