//
//  LoginVC.swift
//  Henceforth_Test
//
//  Created by Parbhat Jayaswal on 10/10/22.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var forgotPassowrd: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        forgotPassowrd.layer.cornerRadius = 4
        forgotPassowrd.layer.borderWidth = 2
        forgotPassowrd.layer.borderColor = UIColor.init(named: "AccentColor")?.cgColor

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
