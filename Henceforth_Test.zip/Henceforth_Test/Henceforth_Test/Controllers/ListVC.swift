//
//  ListVC.swift
//  Henceforth_Test
//
//  Created by Parbhat Jayaswal on 10/10/22.
//

import UIKit
import CoreData

class ListVC: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    
    private var dataSource: [LocationModal] = []

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let result = PersistentStorage.shared.fetchManagedObject(managedObject: Locations.self)
        dataSource.removeAll()
        
        result?.forEach({ (info) in
            dataSource.insert(info.convertToLocation(), at: 0)
        })
        
        tblView.reloadData()
    }
    

}


extension ListVC: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell", for: indexPath) as! ListCell
        cell.configCell(info: dataSource[indexPath.row])
        
        cell.deleteBtn.tag = indexPath.row
        cell.deleteBtn.addTarget(self, action: #selector(self.deleteAction(_:)), for: .touchUpInside)

        return cell
    }
    
    
    @objc func deleteAction(_ sender : UIButton) {
        if(self.delete(id: dataSource[sender.tag].id)) {
            dataSource.remove(at: sender.tag)
            tblView.reloadData()
        }
    }
    
    
}

extension ListVC {
    
    func delete(id: UUID) -> Bool {
        let data = getCDLocation(byIdentifier: id)
        guard data != nil else {return false}
        
        PersistentStorage.shared.context.delete(data!)
        PersistentStorage.shared.saveContext()
        return true
    }
    
    
    private func getCDLocation(byIdentifier id: UUID) -> Locations? {
        let fetchRequest = NSFetchRequest<Locations>(entityName: "Locations")
        let predicate = NSPredicate(format: "id==%@", id as CVarArg)
        
        fetchRequest.predicate = predicate
        do {
            let result = try PersistentStorage.shared.context.fetch(fetchRequest).first
            
            guard result != nil else {return nil}
            
            return result
            
        } catch let error {
            debugPrint(error)
        }
        
        return nil
    }
    
}
