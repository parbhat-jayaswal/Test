//
//  MapVC.swift
//  Henceforth_Test
//
//  Created by Parbhat Jayaswal on 10/10/22.
//

import UIKit
import GoogleMaps
import CoreLocation


class MapVC: UIViewController, CLLocationManagerDelegate, GMSMapViewDelegate {
    
    @IBOutlet weak var mapView: GMSMapView!
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        getCurrentLocations()
        
        mapView.delegate = self
        mapView.isMyLocationEnabled = true
        mapView.settings.myLocationButton = false
    }
    
    func getCurrentLocations() {
        locationManager.delegate = self
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.allowsBackgroundLocationUpdates = true
            locationManager.requestAlwaysAuthorization()
            locationManager.distanceFilter = 4; // meters
            locationManager.startUpdatingLocation()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        mapView.clear()
        PersistentStorage.shared.fetchManagedObject(managedObject: Locations.self)?.forEach({ location in
            let lat = Double(location.lat ?? "0.0")
            let lng = Double(location.lng ?? "0.0")
            let position = CLLocationCoordinate2DMake(lat ?? 0.0, lng ?? 0.0)
            let marker = GMSMarker(position: position)
            marker.map = mapView
        })
    }
    
    //Location Manager delegates
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation = locations.last
        let camera = GMSCameraPosition.camera(withLatitude: userLocation!.coordinate.latitude, longitude: userLocation!.coordinate.longitude, zoom: 15);
        self.mapView.camera = camera
        self.mapView.isMyLocationEnabled = true
        locationManager.stopUpdatingLocation()
    }
    
    
    func mapView(_ mapView: GMSMapView, didTapAt coordinate: CLLocationCoordinate2D) {
        let marker = GMSMarker(position: coordinate)
        marker.position.latitude = coordinate.latitude
        marker.position.longitude = coordinate.longitude
        
        let location = Locations(context: PersistentStorage.shared.context)
        location.id = UUID()
        location.lat = "\(marker.position.latitude)"
        location.lng = "\(marker.position.longitude)"
        PersistentStorage.shared.saveContext()
        
        marker.map = self.mapView
        mapView.delegate = self

     }
    
    
}
