//
//  LocationModal.swift
//  Henceforth_Test
//
//  Created by Parbhat Jayaswal on 10/10/22.
//

import Foundation

struct LocationModal {
    var id: UUID
    var lat: String?
    var lng: String?
}
