//
//  Locations+CoreDataClass.swift
//  Henceforth_Test
//
//  Created by Parbhat Jayaswal on 10/10/22.
//
//

import Foundation
import CoreData

@objc(Locations)
public class Locations: NSManagedObject {

}
