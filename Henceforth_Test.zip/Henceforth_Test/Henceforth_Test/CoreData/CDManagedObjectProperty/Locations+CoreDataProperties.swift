//
//  Locations+CoreDataProperties.swift
//  Henceforth_Test
//
//  Created by Parbhat Jayaswal on 10/10/22.
//
//

import Foundation
import CoreData


extension Locations {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Locations> {
        return NSFetchRequest<Locations>(entityName: "Locations")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var lat: String?
    @NSManaged public var lng: String?

    
    
    func convertToLocation() -> LocationModal {
        return LocationModal(id: id!, lat: lat, lng: lng)
    }
    
}


extension Locations : Identifiable {

}
