//
//  ListCell.swift
//  Henceforth_Test
//
//  Created by Parbhat Jayaswal on 10/10/22.
//

import UIKit

class ListCell: UITableViewCell {

    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var latLbl: UILabel!
    @IBOutlet weak var lngLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configCell(info : LocationModal) {
        latLbl.text = info.lat
        lngLbl.text = info.lng
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
