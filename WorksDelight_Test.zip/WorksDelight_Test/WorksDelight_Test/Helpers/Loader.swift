//
//  Loader.swift
//  WorksDelight_Test
//
//  Created by Parbhat Jayaswal on 21/10/22.
//

import Foundation
import NVActivityIndicatorView

class Loader: UIViewController {
    
    static var shared = Loader()
    private var activityIndicator : NVActivityIndicatorView!
    private let mainView = UIView()
    
    // MARK: - Show Loader
    func show(screenView: UIView) {
        mainView.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1).withAlphaComponent(0.4)
        mainView.frame = screenView.frame
        
        activityIndicator =  NVActivityIndicatorView(frame: CGRect.init(x: Int(screenView.frame.size.width)/2-20, y: Int(screenView.frame.size.height)/2-20, width: 50, height: 50), type: .lineScalePulseOutRapid, color: UIColor.init(named: "AccentColor"), padding: nil)
        
        mainView.addSubview(activityIndicator)
        screenView.addSubview(mainView)
        
        activityIndicator.startAnimating()
    }
    
    // MARK: - Remove Loader
    func hide() {
        mainView.removeFromSuperview()
        activityIndicator.stopAnimating()
    }
    
}

