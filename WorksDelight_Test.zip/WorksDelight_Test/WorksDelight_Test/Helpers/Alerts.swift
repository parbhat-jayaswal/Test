//
//  Alerts.swift
//  WorksDelight_Test
//
//  Created by Parbhat Jayaswal on 21/10/22.
//

import Foundation
import UIKit

struct Alerts {
    
    //MARK::- ALERT WITH OK MESSAGE
    static func alertMessage(title: String, message: String, view : UIViewController) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alert.addAction(action)
        view.present(alert, animated: true, completion: nil)
    }
    
}
