//
//  APIs.swift
//  WorksDelight_Test
//
//  Created by Parbhat Jayaswal on 21/10/22.
//

import Foundation

struct APIs {
    static let baseURL = "https://dietangel.shtibel.com/dietAngel/public/api/"
    
    static let ImgBaseURL = "https://dietangel.shtibel.com/dietAngel/public/"
    
    
    static var login = baseURL + "user/login_faster"
    static var recipeList = baseURL + "user/recipe"
    
}
