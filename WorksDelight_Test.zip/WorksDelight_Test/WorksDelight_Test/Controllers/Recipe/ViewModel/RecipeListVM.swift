//
//  RecipeListVM.swift
//  WorksDelight_Test
//
//  Created by Parbhat Jayaswal on 21/10/22.
//

import Foundation

class RecipeListVM {
    
    private var recipes: [Recipes] = []
    
    private func setupInfo(recipe: RecipeModel) {
        recipe.data.forEach { info in
            print(info)
            info.recipes.forEach { r in
                print(r)
                recipes.append(r)
            }
        }
    }
    
    func numberOfRowsInSection(_ section: Int) -> Int {
        return self.recipes.count
    }
    
    func recipeAtIndex(_ index: Int) -> Recipes {
        let recipe = self.recipes[index]
        return recipe
    }
    
    
    func getRecipeByApi(completionHandler: @escaping (RecipeModel?) -> Swift.Void) {
        guard let gitUrl = URL(string: APIs.recipeList) else { return }
        
        let request = NSMutableURLRequest(url: gitUrl)
        
        let token = UserDefaults.standard.value(forKey: "token") ?? ""
        
        let session = URLSession.shared
        request.httpMethod = "GET"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue( "Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        let task = session.dataTask(with: request as URLRequest) { data, response, error in
            guard let data = data else { return }
            do {
                //  let decoder = JSONDecoder()
                //  here replace LoginData with your codable structure.
                let gitData = try JSONDecoder().decode(RecipeModel.self, from: data)
                print("response data:", gitData)
                
                self.setupInfo(recipe: gitData)
                
                completionHandler(gitData)
            } catch let err {
                completionHandler(nil)
                print("Err", err)
            }
        }
        task.resume()
    }
    
}


