//
//  RecipeListVC.swift
//  WorksDelight_Test
//
//  Created by Parbhat Jayaswal on 21/10/22.
//

import UIKit

class RecipeListVC: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    
    fileprivate var objRecipeListVM = RecipeListVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initilize()
    }
    
    fileprivate func initilize() {
        setupNav()
        getRecipes()
    }
    
    fileprivate func setupNav() {
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.title = "Recipes"
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Logout", style: .done, target: self, action: #selector(addTapped))
    }
    
    @objc func addTapped(sender: UIBarButtonItem) {
        UserDefaults.standard.removeObject(forKey: "token")
        let viewControllers: [UIViewController] = self.navigationController!.viewControllers as [UIViewController]
        self.navigationController!.popToViewController(viewControllers[0], animated: true)
    }
    
    fileprivate func getRecipes() {
        Loader.shared.show(screenView: self.view)
        objRecipeListVM.getRecipeByApi { responce in
            if let status = responce?.status, status == 1 {
                DispatchQueue.main.async { self.tblView.reloadData() }
            } else {
                DispatchQueue.main.async { Alerts.alertMessage(title: "Test", message: "Server Error", view: self) }
            }
            DispatchQueue.main.async { Loader.shared.hide() }
        }
    }
    
}

extension RecipeListVC : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objRecipeListVM.numberOfRowsInSection(section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecipeListCell", for: indexPath) as! RecipeListCell
        cell.configCell(info: self.objRecipeListVM.recipeAtIndex(indexPath.row))
        return cell
    }
}
