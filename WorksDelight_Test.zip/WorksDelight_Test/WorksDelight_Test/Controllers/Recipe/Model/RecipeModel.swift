//
//  RecipeModel.swift
//  WorksDelight_Test
//
//  Created by Parbhat Jayaswal on 21/10/22.
//

import Foundation

struct RecipeModel: Codable {
    let status: Int
    let data: [RecipeData]
    
    enum CodingKeys: String, CodingKey {
        case status
        case data = "data"
    }
}


struct RecipeData: Codable {
    var recipes: [Recipes]
    enum CodingKeys: String, CodingKey {
        case recipes = "recipe"
    }
}

struct Recipes : Codable {
    var title: String?
    var description: String?
    var image: String?
}
