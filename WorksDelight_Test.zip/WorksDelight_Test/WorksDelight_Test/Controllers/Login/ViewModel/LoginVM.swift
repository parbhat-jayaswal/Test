//
//  LoginVM.swift
//  WorksDelight_Test
//
//  Created by Parbhat Jayaswal on 21/10/22.
//

import Foundation


class LoginVM {
    
    private var loginModel = LoginParams()

    var email: String? {
        get { loginModel.email }
        set { loginModel.email = newValue }
    }
    
    var password: String? {
        get { loginModel.password }
        set { loginModel.password = newValue }
    }
    
    func getLoginModel() -> [String: Any] {
       return ["email": self.email!,
               "password": self.password!,
               "one_signal_id": "",
               "app_version": "",
               "device_type": ""]
    }    
    
    func loginByApi(completionHandler: @escaping (LoginResponce?) -> Swift.Void) {
        
        guard let gitUrl = URL(string: APIs.login) else { return }
        
        let params = getLoginModel()
        
        let request = NSMutableURLRequest(url: gitUrl)
        
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        request.httpBody = try! JSONSerialization.data(withJSONObject: params, options: [])
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, response, error in
            guard let data = data else { return }
            do {
                let gitData = try JSONDecoder().decode(LoginResponce.self, from: data)
                completionHandler(gitData)
            } catch let err {
                print("Error", err.localizedDescription)
            }
        }
        task.resume()
    }
    
}

