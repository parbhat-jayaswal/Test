//
//  LoginVC.swift
//  WorksDelight_Test
//
//  Created by Parbhat Jayaswal on 21/10/22.
//

import UIKit

class LoginVC: UIViewController {
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passordTF: UITextField!
    @IBOutlet weak var forgotPassowrd: UIButton!
    
    fileprivate var objLoginVM = LoginVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initilize()
    }
    
    fileprivate func initilize() {
        moveToRecipes()
        forgotPasswordBorder()
    }
    
    private func moveToRecipes() {
        if let _  = UserDefaults.standard.value(forKey: "token") as? String {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "RecipeListVC") as! RecipeListVC
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
    fileprivate func forgotPasswordBorder() {
        forgotPassowrd.layer.cornerRadius = 4
        forgotPassowrd.layer.borderWidth = 2
        forgotPassowrd.layer.borderColor = UIColor.init(named: "AccentColor")?.cgColor
    }
    
    @IBAction func loginBtnAction(_ sender: UIButton) {
        fieldsValiation()
    }
}

extension LoginVC {
    fileprivate func fieldsValiation() {
        guard let email = emailTF.text, email != "" else {
            Alerts.alertMessage(title: "Email Address", message: "Email can't be empty!", view: self)
            return
        }
        
        if !(email.isValidEmail) {
            Alerts.alertMessage(title: "Email Address", message: "Enter valid email address!", view: self)
        } else {
            guard let password = passordTF.text, password != "" else {
                Alerts.alertMessage(title: "Password", message: "Password can't be empty!", view: self)
                return
            }
            objLoginVM.email = email
            objLoginVM.password = password
            callLoginAPI()
        }
    }
    
    fileprivate func callLoginAPI() {
        Loader.shared.show(screenView: self.view)
        objLoginVM.loginByApi() { responce in
            if let status = responce?.status, status == 1 {
                UserDefaults.standard.setValue(responce?.loginData?.token, forKey: "token")
                DispatchQueue.main.async {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "RecipeListVC") as! RecipeListVC
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            } else {
                DispatchQueue.main.async {
                    Alerts.alertMessage(title: "Error", message: responce?.message ?? "Server Error!", view: self)
                }
            }
            DispatchQueue.main.async { Loader.shared.hide() }
        }
    }
}

