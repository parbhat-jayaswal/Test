//
//  LoginModal.swift
//  WorksDelight_Test
//
//  Created by Parbhat Jayaswal on 21/10/22.
//

import Foundation

struct LoginParams {
    var email: String?
    var password: String?
}


struct LoginResponce: Codable {
    var status: Int?
    var message: String?
    var loginData: LoginData?
    
    enum CodingKeys: String, CodingKey {
        case status
        case message
        case loginData = "data"
    }
}

struct LoginData: Codable {
    let token: String?
}

